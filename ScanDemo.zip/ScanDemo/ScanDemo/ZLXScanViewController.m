//
//  ZLXScanViewController.m
//  ScanDemo
//
//  Created by leo on 2018/4/4.
//  Copyright © 2018年 zlx. All rights reserved.
//

#import "ZLXScanViewController.h"
#import "AppDelegate.h"
@interface ZLXScanViewController ()<AVCaptureMetadataOutputObjectsDelegate,AVCapturePhotoCaptureDelegate>
@property(nonatomic,strong)AVAudioPlayer *audioPlayer; //声音提示
@property (nonatomic, strong) AVCaptureSession *captureSession;
@property (nonatomic, strong) AVCaptureDeviceInput *captureInput;
@property (nonatomic, strong)AVCaptureMetadataOutput *captureOutput;


@end

@implementation ZLXScanViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /*
     AVAuthorizationStatusNotDetermined 未授权
     AVAuthorizationStatusRestricted,
     AVAuthorizationStatusDenied,
     AVAuthorizationStatusAuthorized 已授权可使用
     */
    AVAuthorizationStatus authStatus =  [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    NSLog(@"--- %ld",authStatus);
    switch (authStatus) {
        case AVAuthorizationStatusNotDetermined:
            NSLog(@"--  提示授权 --");
            break;
        case AVAuthorizationStatusAuthorized:
            NSLog(@"--  已授权 --");
            break;
        default:
            break;
    }
    [self initCaptureSession];
    [self startRunning];
   // [self cameraBackgroundDidClickOpenAntiShake];//防抖
    
    [[self.captureInput device] addObserver:self forKeyPath:@"ISO" options:NSKeyValueObservingOptionNew context:NULL];//感光度
    [[self.captureInput device] addObserver:self forKeyPath:@"adjustingFocus" options:NSKeyValueObservingOptionNew context:nil];//焦距
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //[self.view layoutSubviews];
    [self initCa];
}
-(void)initCa{
    AVCaptureDevice *captureDevice = [self.captureInput device];
    NSError *error;
    if ([captureDevice lockForConfiguration:&error]) {
        if ([captureDevice isFocusModeSupported:AVCaptureFocusModeContinuousAutoFocus])
            [captureDevice setFocusMode:AVCaptureFocusModeContinuousAutoFocus];
        
        if ([captureDevice isExposureModeSupported:AVCaptureExposureModeContinuousAutoExposure])
            [captureDevice setExposureMode:AVCaptureExposureModeContinuousAutoExposure];
        if ([captureDevice isExposurePointOfInterestSupported])
            [captureDevice setExposurePointOfInterest:CGPointMake(0.5, 0.5)];
    }
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[self.captureInput device] removeObserver:self forKeyPath:@"ISO"];
    [[self.captureInput device] removeObserver:self forKeyPath:@"adjustingFocus"];
}
- (IBAction)backBtnClick:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:^{
        [self stopRunning];
    }];
}


-(void)initCaptureSession{
    NSError *error = nil;
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    AVCaptureDeviceInput *captureInput = [AVCaptureDeviceInput deviceInputWithDevice:device error:&error];
    if (error) {
        return;
    }
    self.captureInput = captureInput;

    AVCaptureMetadataOutput *captureOutput = [[AVCaptureMetadataOutput alloc] init];
    [captureOutput setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    

    self.captureSession = [[AVCaptureSession alloc] init];
    [self.captureSession setSessionPreset:AVCaptureSessionPresetPhoto];

    [self.captureSession addInput:captureInput];
    [self.captureSession addOutput:captureOutput];
    if (captureOutput) {
        //设置扫码支持的编码格式
        NSMutableArray *array = [[NSMutableArray alloc]initWithCapacity:0];
        if ([captureOutput.availableMetadataObjectTypes containsObject:AVMetadataObjectTypeQRCode]) {
            [array addObject:AVMetadataObjectTypeQRCode];
        } if ([captureOutput.availableMetadataObjectTypes containsObject:AVMetadataObjectTypeEAN13Code]) {
            [array addObject:AVMetadataObjectTypeEAN13Code];
        } if ([captureOutput.availableMetadataObjectTypes containsObject:AVMetadataObjectTypeEAN8Code]) {
            [array addObject:AVMetadataObjectTypeEAN8Code];
        } if ([captureOutput.availableMetadataObjectTypes containsObject:AVMetadataObjectTypeDataMatrixCode]) {
            [array addObject:AVMetadataObjectTypeDataMatrixCode];
        }if ([captureOutput.availableMetadataObjectTypes containsObject:AVMetadataObjectTypeCode39Code]) {
            [array addObject:AVMetadataObjectTypeCode39Code];
        }
        captureOutput.metadataObjectTypes = array;
    }
    self.captureOutput = captureOutput;
    AVCaptureVideoPreviewLayer *previewLayer = [AVCaptureVideoPreviewLayer layerWithSession:self.captureSession];
    previewLayer.frame = [[UIApplication sharedApplication].delegate window].frame;
    previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    [self.view.layer insertSublayer:previewLayer atIndex:0];

}
#pragma mark - AVCaptureMetadataOutputObjectsDelegate
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection {
    NSLog(@"---- %@",NSStringFromCGPoint(captureOutput.accessibilityActivationPoint));

    if (metadataObjects.count > 0) {
        AVMetadataMachineReadableCodeObject *metadataObject = metadataObjects[0];
        NSString *result = metadataObject.stringValue;
        NSLog(@"---- %@",result);
        connection.enabled = NO;
        [self backBtnClick:nil];

        if (self.delegate&&[self.delegate respondsToSelector:@selector(scanViewController:didFinishScanWithData:)]) {
            [self.delegate scanViewController:self didFinishScanWithData:result];
        }
    }
}


#pragma -mark - 屏幕点击
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    NSLog(@"%@  --",NSStringFromCGPoint([[touches anyObject] locationInView:self.view]));
    [self cameraBackgroundDidTap:[[touches anyObject] locationInView:self.view]];
}
// 当前屏幕上点击的点坐标
- (void)cameraBackgroundDidTap:(CGPoint)point {
    AVCaptureDeviceInput *devInput = self.captureSession.inputs[0];

    AVCaptureDevice *captureDevice = [devInput device];
    NSError *error;
    if ([captureDevice lockForConfiguration:&error]) {
        CGPoint location = point;
        CGPoint pointOfInerest = CGPointMake(0.5, 0.5);
        CGSize frameSize = self.view.frame.size;
        if ([captureDevice position] == AVCaptureDevicePositionFront)
            location.x = frameSize.width - location.x;
        pointOfInerest = CGPointMake(location.y / frameSize.height, 1.f - (location.x / frameSize.width));
        [self focusWithMode:AVCaptureFocusModeAutoFocus exposureMode:AVCaptureExposureModeAutoExpose  atPoint:pointOfInerest];
        
        
    }else{
        // Handle the error appropriately.
    }
}
#pragma mark - KVO回调
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context {
    if ([keyPath isEqualToString:@"ISO"]) {
        AVCaptureDeviceInput *devInput = self.captureSession.inputs[0];
        CGFloat minISO = devInput.device.activeFormat.minISO;
        CGFloat maxISO = devInput.device.activeFormat.maxISO;
        CGFloat currentISO = devInput.device.ISO;
        CGFloat value = (currentISO - minISO) / (maxISO - minISO);
         //NSLog(@"ISO = %lf",value);
        //[self cameraBackgroundDidChangeISO:value];
    }
    
    if([keyPath isEqualToString:@"adjustingFocus"]){
        BOOL adjustingFocus =[[change objectForKey:NSKeyValueChangeNewKey] isEqualToNumber:[NSNumber numberWithInt:1]];
        
         NSLog(@"adjustingFocus~~%d  change~~%@", adjustingFocus, change);
        // 0 == 焦距不发生改变 1 == 焦距改变
        if (adjustingFocus == 1) {
            
        }
        
    }
}
#pragma -mark - 防抖
- (void)cameraBackgroundDidClickOpenAntiShake {
    AVCaptureConnection *captureConnection = [self.captureSession.outputs[0] connectionWithMediaType:AVMediaTypeVideo];
    AVCaptureDeviceInput *devInput = self.captureSession.inputs[0];
    NSLog(@"change captureConnection: %@", captureConnection);
    AVCaptureDevice *videoDevice = devInput.device;
    NSLog(@"set format: %@", videoDevice.activeFormat);
    if ([videoDevice.activeFormat isVideoStabilizationModeSupported:AVCaptureVideoStabilizationModeCinematic]) {
        captureConnection.preferredVideoStabilizationMode = AVCaptureVideoStabilizationModeCinematic;
    }
}

#pragma -mark - 点击屏幕自动对焦
-(void)focusWithMode:(AVCaptureFocusMode)focusMode exposureMode:(AVCaptureExposureMode)exposureMode atPoint:(CGPoint)point{
    AVCaptureDeviceInput *devInput = self.captureSession.inputs[0];
    AVCaptureDevice *captureDevice = [devInput device];
    NSError *error;
    NSLog(@"");
    if ([captureDevice lockForConfiguration:&error]) {
        if ([captureDevice isFocusModeSupported:focusMode])
            [captureDevice setFocusMode:AVCaptureFocusModeAutoFocus];
        if ([captureDevice isFocusPointOfInterestSupported])
            [captureDevice setFocusPointOfInterest:point];
        if ([captureDevice isExposureModeSupported:exposureMode])
            [captureDevice setExposureMode:AVCaptureExposureModeAutoExpose];
        if ([captureDevice isExposurePointOfInterestSupported])
            [captureDevice setExposurePointOfInterest:point];
    }else{
        //  error
    }
    NSLog(@"-- %@",NSStringFromCGPoint(point));
    self.captureOutput.rectOfInterest = CGRectMake(point.x-0.2, point.y-0.2, 0.4, 0.4);

}

// 调节ISO光感度 0.0-1.0
- (void)cameraBackgroundDidChangeISO:(CGFloat)iso {
    AVCaptureDeviceInput *devInput = self.captureSession.inputs[0];
    AVCaptureDevice *captureDevice = [devInput device];
    NSError *error;
    if ([captureDevice lockForConfiguration:&error]) {
        CGFloat minISO = captureDevice.activeFormat.minISO;
        CGFloat maxISO = captureDevice.activeFormat.maxISO;
        CGFloat currentISO = (maxISO - minISO) * iso + minISO;
        [captureDevice setExposureModeCustomWithDuration:AVCaptureExposureDurationCurrent ISO:currentISO completionHandler:nil];
        [captureDevice unlockForConfiguration];
    }else{
        // Handle the error appropriately.
    }
}

#pragma -mark - 提示音
//可以在成功扫描时播放
- (void)loadBeepSound
{
    NSString *beepFilePath = [[NSBundle mainBundle] pathForResource:@"beep-beep" ofType:@"aiff"];
    NSURL *beepURL = [NSURL URLWithString:beepFilePath];
    
    NSError *error;
    
    // Initialize the audio player object using the NSURL object previously set.
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:beepURL error:&error];
    if (error) {
        // If the audio player cannot be initialized then log a message.
        NSLog(@"Could not play beep file.");
        NSLog(@"%@", [error localizedDescription]);
    } else {
        // If the audio player was successfully initialized then load it in memory.
        [self.audioPlayer prepareToPlay];
    }
}

- (void)startRunning {
    if (self.captureSession) {
        [self.captureSession startRunning];
    }
}
- (void)stopRunning {
    [self.captureSession stopRunning];
}

-(void)dealloc{
    NSLog(@"xxxxxxx");
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
