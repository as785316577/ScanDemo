//
//  ViewController.m
//  ScanDemo
//
//  Created by leo on 2018/4/4.
//  Copyright © 2018年 zlx. All rights reserved.
//

#import "ViewController.h"
#import "ZLXScanViewController.h"
@interface ViewController ()<ZLXScanVCDelegate>
@property (weak, nonatomic) IBOutlet UITextView *resultStr;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)scanBtnClick:(UIButton *)sender {
    ZLXScanViewController *svc = [[ZLXScanViewController alloc] initWithNibName:@"ZLXScanViewController" bundle:nil];
    svc.delegate = self;
    [self presentViewController:svc animated:YES completion:nil];
}
-(void)scanViewController:(UIViewController *)scanVC didFinishScanWithData:(NSString *)scanObjs{
    self.resultStr.text = scanObjs;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
