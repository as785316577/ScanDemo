//
//  ZLXScanViewController.h
//  ScanDemo
//
//  Created by leo on 2018/4/4.
//  Copyright © 2018年 zlx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>


@protocol ZLXScanVCDelegate <NSObject>

-(void)scanViewController:(UIViewController *)scanVC didFinishScanWithData:(NSString *)scanObjs;

@end

@interface ZLXScanViewController : UIViewController
@property (nonatomic, weak) id<ZLXScanVCDelegate> delegate;
@property (weak, nonatomic) IBOutlet UIView *videoPreview;
@property (weak, nonatomic) IBOutlet UIButton *backBtn;
@property (weak, nonatomic) IBOutlet UILabel *subTitle;

@end
